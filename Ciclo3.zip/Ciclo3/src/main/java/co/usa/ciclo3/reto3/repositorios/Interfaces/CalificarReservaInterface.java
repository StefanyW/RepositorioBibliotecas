/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.usa.ciclo3.reto3.repositorios.Interfaces;

import co.usa.ciclo3.reto3.modelo.CalificarReserva;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author StefanyW
 */
public interface CalificarReservaInterface extends CrudRepository<CalificarReserva, Long>{
    
}
