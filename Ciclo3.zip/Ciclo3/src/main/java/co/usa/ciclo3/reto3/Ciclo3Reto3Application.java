package co.usa.ciclo3.reto3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ciclo3Reto3Application {

	public static void main(String[] args) {
		SpringApplication.run(Ciclo3Reto3Application.class, args);
	}

}
