package co.usa.ciclo3.retoCiclo3.service;

public class MessageService {
}
