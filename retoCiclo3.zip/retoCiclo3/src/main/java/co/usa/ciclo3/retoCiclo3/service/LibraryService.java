package co.usa.ciclo3.retoCiclo3.service;

import co.usa.ciclo3.retoCiclo3.Repository.LibraryRepository;
import co.usa.ciclo3.retoCiclo3.model.Library;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LibraryService {

    @Autowired
    private LibraryRepository libraryRepository;

    public List<Library> getAll() {
        return libraryRepository.getAll();
    }

    public Optional<Library> getLibrary(int id) {
        return libraryRepository.getLibrary(id);
    }

    public Library save(Library l) {
        if (l.getId() == null) {
            return libraryRepository.save(l);
        } else {
            Optional<Library> lib = libraryRepository.getLibrary(l.getId());
            if (lib.isEmpty()) {
                return libraryRepository.save(l);
            } else {
                return l;
            }
        }
    }

}
