package co.usa.ciclo3.retoCiclo3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetoCiclo3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
